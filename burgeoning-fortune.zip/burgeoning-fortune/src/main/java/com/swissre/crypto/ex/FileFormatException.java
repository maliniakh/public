package com.swissre.crypto.ex;

public class FileFormatException extends Exception {
    public FileFormatException() {
    }

    public FileFormatException(String message) {
        super(message);
    }
}
